#include<iostream>
#include<memory>
#include<string>

using std::cin;
using std::cout;
using std::endl;
using std::string;

double coins[] = {0.01, 0.05, 0.1, 0.25};


class Item
{
 public:

    
    string name;
    double cost;

    Item() {}
    Item(string name, double cost)
    {
        this-> name = name;
        this->cost = cost;
    }

};





//-----------------------------------//

int calcChange(Item item, double amount, double input)
{
    double total = item.cost * amount; 

    double change = input - total;
    double tempChange = change;
    
    if (change < 0)
    {
        cout<<"Your total is "<<total<<" and you paid "<<input<<"\nYou didn't pay enough, now leave."<<endl;
    }
    else
    {
            //cout << change << endl;

        int q = change / 0.25;
        change = change - q*0.25;
        
        int d = change / 0.10;
        change = change - d*0.10;
        
        int n = change / 0.05;
        change = change - n*0.05;
        
        int p = change / 0.01;
        change = change - p*0.01;


        cout <<"Your change is "<<tempChange<<". It will be " <<q<< " quarters, " <<d<<" dimes, "<<n<<" nickels, "<<p<< " pennies "<<endl;     
    }
    
    return 0;
};



int main()
{
    int userInput;
    double userDinput;
    Item tempItem;

    Item coffee ("Coffee $4.50", 4.50);
    Item vanilla ("Vanilla Coffee $5.27", 5.27);
    Item cheesy ("Cheesy Coffee $9.99", 9.99);
    Item tea ("Tea $2.10", 2.10);
    Item red("Red Tea $2.62", 2.62);
    Item sandwhich ("Sandwhich $5.00", 5.00);
    Item bacon ("Big Dollar Bacon $11.59", 11.59);
    Item water ("Water $0", 0);
    

    string menu[] = {coffee.name, vanilla.name, cheesy.name, tea.name, red.name, sandwhich.name, bacon.name, water.name};

    for (size_t i = 0; i < 8; i++)
    {
        cout<<i+1<<". "<<menu[i]<<endl;
    }
    
    cout<<"What would you like to order?\n"<<endl;
    cin >> userInput;
    switch (userInput)
    {
    case 1: tempItem = coffee;
        break;
        case 2: tempItem = vanilla;
        break;
        case 3: tempItem = cheesy;
        break;
        case 4: tempItem = tea;
        break; 
        case 5: tempItem = red;
        break;
        case 6: tempItem = sandwhich;
        break;
        case 7: tempItem = bacon;
        break;
        case 8: tempItem = water;
        break;   
    }
    cout<<"How many do you want?\n"<<endl;
    cin >> userInput;
    cout<<"How much will you pay (ex. 3.55)?\n";
    cin>>userDinput;
    cout << "You ordered "<< userInput <<" "<< tempItem.name << "(s)."<<endl;
 
    calcChange(tempItem, userInput, userDinput);
    
}